/* Placeholder for project images */
/* Add your project screenshots here:
- construction-management.jpg
- customer-care.jpg  
- salary-management.jpg
- visualfairy.jpg
- pacman-game.jpg
- bmi-calculator.jpg
- Hirumi_Weerasooriya_CV.pdf
*/

/* Recommended size for project images: 600x400px */
